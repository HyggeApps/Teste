import streamlit as st

st.title('Teste AWS EC2')
